function checkConnection() {

try{
    
    var networkState = navigator.connection.type;

            var states = {};
            states[Connection.UNKNOWN]  = 'Unknown connection';
            states[Connection.ETHERNET] = 'Ethernet connection';
            states[Connection.WIFI]     = 'WiFi connection';
            states[Connection.CELL_2G]  = 'Cell 2G connection';
            states[Connection.CELL_3G]  = 'Cell 3G connection';
            states[Connection.CELL_4G]  = 'Cell 4G connection';
            states[Connection.CELL]     = 'Cell generic connection';
            states[Connection.NONE]     = 'No network connection';

            alert('Connection type: ' + states[networkState]);
}catch(e){
     console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&'+e);
	alert(""+e);
}

}


 function getValue(){
               var name ="";
			   var desc ="";
 
                     $.ajax({
					  type: 'GET',
					  url: "http://localhost:8084/RestApi/ValidateInput?first_name=&last_name=",
					  data: {'numberOfWords' : 10}, //How can I preview this?
					  dataType: 'json',
					  async: false, //This is deprecated in the latest version of jquery must use now callbacks
					  success: function(d){
					   alert(d.status); //will alert ok
					  }
					});
					
					
					


 }
 
 getValue();