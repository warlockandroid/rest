/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shuvankar
 */
public class GetResponseJson extends HttpServlet {

     // Method to handle GET method request.
    
    String reponse = "{\n" +
"  \"Device Coolers\": [\n" +
"    {\n" +
"      \"location_id\": \"123,\",\n" +
"      \"device_id\": \"123,\",\n" +
"      \"start_time\": \"123,\",\n" +
"      \"switch_on_after\": \"123,\",\n" +
"      \"switch_on_for\": \"123,\",\n" +
"      \"switch_off_after\": \"123,\",\n" +
"      \"switch_off_for\": \"123,\",\n" +
"      \"temperature\": \"123,\",\n" +
"      \"end_time\": \"123,\",\n" +
"      \"power_consumption\": \"123,\",\n" +
"      \"number_of_units\": \"123\"\n" +
"    },\n" +
"    {\n" +
"      \"location_id\": \"1234,\",\n" +
"      \"device_id\": \"1234,\",\n" +
"      \"start_time\": \"1234,\",\n" +
"      \"switch_on_after\": \"1234,\",\n" +
"      \"switch_on_for\": \"1234,\",\n" +
"      \"switch_off_after\": \"1234,\",\n" +
"      \"switch_off_for\": \"1234,\",\n" +
"      \"temperature\": \"1234,\",\n" +
"      \"end_time\": \"1234,\",\n" +
"      \"power_consumption\": \"1234,\",\n" +
"      \"number_of_units\": \"1234\"\n" +
"      \n" +
"      \n" +
"      \n" +
"      \n" +
"    }\n" +
"  ],\n" +
"  \n" +
"  \n" +
"  \"Device Freezer\": [\n" +
"    {\n" +
"      \"location_id\": \"123,\",\n" +
"      \"device_id\": \"123,\",\n" +
"      \"start_time\": \"123,\",\n" +
"      \"switch_on_after\": \"123,\",\n" +
"      \"switch_on_for\": \"123,\",\n" +
"      \"switch_off_after\": \"123,\",\n" +
"      \"switch_off_for\": \"123,\",\n" +
"      \"temperature\": \"123,\",\n" +
"      \"end_time\": \"123,\",\n" +
"      \"power_consumption\": \"123,\",\n" +
"      \"number_of_units\": \"123\"\n" +
"    },\n" +
"    {\n" +
"      \"location_id\": \"1234,\",\n" +
"      \"device_id\": \"1234,\",\n" +
"      \"start_time\": \"1234,\",\n" +
"      \"switch_on_after\": \"1234,\",\n" +
"      \"switch_on_for\": \"1234,\",\n" +
"      \"switch_off_after\": \"1234,\",\n" +
"      \"switch_off_for\": \"1234,\",\n" +
"      \"temperature\": \"1234,\",\n" +
"      \"end_time\": \"1234,\",\n" +
"      \"power_consumption\": \"1234,\",\n" +
"      \"number_of_units\": \"1234\"\n" +
"      \n" +
"      \n" +
"      \n" +
"      \n" +
"    }\n" +
"  ]\n" +
"}";
  @Override
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
     /* // Set response content type
//      response.setContentType("text/html");

      PrintWriter out = response.getWriter();
	  String title = "Using GET Method to Read Form Data";
//      String docType =
//      "<!doctype html public \"-//w3c//dtd html 4.0 " +
//      "transitional//en\">\n";
//      out.println(docType +
//                "<html>\n" +
//                "<head><title>" + title + "</title></head>\n" +
//                "<body bgcolor=\"#f0f0f0\">\n" +
//                "<h1 align=\"center\">" + title + "</h1>\n" +
//                "<ul>\n" +
//                "  <li><b>First Name</b>: "
//                + request.getParameter("first_name") + "\n" +
//                "  <li><b>Last Name</b>: "
//                + request.getParameter("last_name") + "\n" +
//                "</ul>\n" +
//                "</body></html>");
          
          response.setContentType("application/json"); 
          response.setCharacterEncoding("UTF-8"); 
//          response.getWriter().write(json);
          
          
//          if(request.getParameter("first_name").equalsIgnoreCase("shuvankar") && request.getParameter("last_name").equalsIgnoreCase("chakraborty")){
//               response.getWriter().write("{status:\"success\"}");
//          }else{
//               response.getWriter().write("{status:\"error\"}");
//          }
          
          response.getWriter().write(reponse);*/
      
              response.setContentType("text/html");
		
		//
		// We are going to read a file called configuration.properties. This
		// file is placed under the WEB-INF directory.
		//
		String filename = "/WEB-INF/wisc-v-block_design.json";
		
		ServletContext context = getServletContext();
		
		//
		// First get the file InputStream using ServletContext.getResourceAsStream()
		// method.
		//
		InputStream is = context.getResourceAsStream(filename);
		if (is != null) {
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader reader = new BufferedReader(isr);
			PrintWriter writer = response.getWriter();
			
			
			//
			// We read the file line by line and later will be displayed on the 
			// browser page.
			//
			while ((reponse = reader.readLine()) != null) {
				writer.println(reponse);
			}
                        response.getWriter().write(reponse);
		}
      
      
      
              
              }
 
  // Method to handle POST method request.
  @Override
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {
     doGet(request, response);
  }
  
  
  
}
