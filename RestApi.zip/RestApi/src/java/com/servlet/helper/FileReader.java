/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.servlet.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.file.Files;

/**
 *
 * @author shuvankar
 */
public class FileReader {
    
    String path;

    public FileReader(String path) {
        //To change body of generated methods, choose Tools | Templates.
        this.path = path;
        
    }
    
    
    
}
